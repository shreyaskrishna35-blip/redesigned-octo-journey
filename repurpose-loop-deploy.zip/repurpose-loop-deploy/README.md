# RePurpose Loop AI — Deployable static website

This version is a self-contained static website. It does **not** require Node.js, npm, React, or a build step.

## Deploy to Netlify (fastest)
1. Download and extract the ZIP.
2. Open https://app.netlify.com/drop
3. Drag the extracted `repurpose-loop-deploy` folder (or its contents) into the drop area.
4. Netlify will publish the website and give you a public URL.

## Deploy with GitHub
1. Create a new GitHub repository.
2. Upload `index.html` and `README.md` to the repository root.
3. In Netlify, choose **Add new site → Import an existing project**, connect the repository, and set:
   - Build command: leave blank
   - Publish directory: `.`
4. Deploy.

## Features in this prototype
- Responsive homepage and navigation
- Marketplace browse/search/category filtering
- Add items with optional photo upload
- Community requests
- Explainable rule-based matching
- Reserve items and mark exchanges complete
- Impact dashboard with estimated item weights
- Browser localStorage persistence

## Honest limitations
- This is a front-end-only demo. Data is saved in the current browser only, not shared between users.
- The AI assistant is a filename-based fallback and does not call a live AI model.
- There is no authentication, cloud database, or secure multi-user reservation backend yet.
- Seeded exchanges/items are demo records and impact numbers include those labelled examples.

For a true multi-user version, connect a backend/database and a server-side AI endpoint before claiming live AI or shared community data.
